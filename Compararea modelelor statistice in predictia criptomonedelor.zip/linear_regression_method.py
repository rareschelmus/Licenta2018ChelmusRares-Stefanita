import pandas
import numpy as np
from sklearn import linear_model
import matplotlib.pyplot as plt
import datetime


class LinearRegressionMethod:
    startDate=""
    data_test=pandas.DataFrame()
    data_training=pandas.DataFrame()
    linear_mod = linear_model.LinearRegression()
    coin =""

    def LinearRegressionMethod(self):
        return 1

    def setData(self,price_data_set):
        self.data_training=price_data_set[:-10]
        self.data_test=price_data_set[-10:]
        return 1

    def setCoin(self,coin):
        self.coin=coin

    def setTrainingData(self, training_set):
        return 1

    def setTestingData(self, startDate, endDate):
        return 1

    def setDate(self, date):
        self.startDate=date

    def train(self):
        dates = np.reshape(range(1,len(self.data_training["date"])+1), (len(self.data_training["date"]), 1))
        prices = np.reshape(self.data_training["close"], (len(self.data_training["close"]), 1))
        print(dates)
        print(prices)
        self.linear_mod.fit(dates, prices)
        return 1

    def testPrediction(self):
        prediction = []
        days=range(len(self.data_training["date"]),len(self.data_training["date"])+len(self.data_test["date"]))
        for day in days:
            predicted_price = self.linear_mod.predict(day)
            # baga aici diferenta, acolo la +250
            prediction.append(predicted_price[0][0]) #+ 250)
        print(prediction)

    def newPrediction(self):
        prediction = []
        days = range(len(self.data_training["date"]), len(self.data_training["date"]) + len(self.data_test["date"]))
        for day in days:
            predicted_price = self.linear_mod.predict(day)
            prediction.append(predicted_price[0][0])

        dates=self.generateDates(self.data_training["date"][self.data_training.index[-1]],10)

        prediction_frame = pandas.DataFrame(data=prediction[0:], index=dates,
                                             columns=["predicted_prices"])

        prediction_plot = prediction_frame.plot()
        plt.gcf().subplots_adjust(bottom=0.15)
        # plt.setp()

        prediction_figure=prediction_plot.get_figure()
        prediction_figure.savefig(self.coin+"_"+dates[0]+"-"+dates[-1]+".png")
        print(prediction)

    def generateDates(self, startDate,period):
        start = datetime.datetime.strptime(startDate, "%Y-%m-%d")
        step = datetime.timedelta(days=1)
        dates = []
        for i in range(0,period):
            start += step
            dates.append(str(start.date()))
        return dates
