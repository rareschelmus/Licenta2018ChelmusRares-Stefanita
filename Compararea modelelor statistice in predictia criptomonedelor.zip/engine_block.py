from crawler_news import NewsCrawler
from crawler_price import PriceCrawler
from sentiment_analysis_module import SentimentAnalyzer_module
from linear_regression_method import LinearRegressionMethod
from random_forest_module import RandomForestModule

coin="ethereum"
startDate="2018-01-15"
endDate="2018-06-14"


def getNews():
    c_news = NewsCrawler()
    c_news.setCoin(coin)
    c_news.setStartDate(startDate)
    c_news.setEndDate(endDate)
    return c_news.getDataPandas()

def getPrices():
    c_price = PriceCrawler()
    c_price.setCoin(coin)
    c_price.setStartDate(startDate)
    c_price.setEndDate(endDate)
    return c_price.getDataPandas()

def main():
    # sentiment_module=SentimentAnalyzer_module()
    # sentiment_module.setDate(startDate,endDate)
    # data=getNews()
    # print(data)
    # sentiment_module.scoreSentimentAnalysis(data)


    # linear_mod=LinearRegressionMethod()
    # linear_mod.setCoin(coin)
    # linear_mod.setData(getPrices())
    # linear_mod.train()
    # linear_mod.newPrediction()

    random_forest_mod=RandomForestModule()
    random_forest_mod.setCoin(coin)
    # random_forest_mod.setData(getPrices(),sentiment_module.scoreFilter_BlankPadding("rares"))
    random_forest_mod.setDataPrice(getPrices())
    random_forest_mod.testNormal()

main()
